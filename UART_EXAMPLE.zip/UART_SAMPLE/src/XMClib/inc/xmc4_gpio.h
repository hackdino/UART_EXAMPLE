/*
 * Copyright (C) 2015 Infineon Technologies AG. All rights reserved.
 *
 * Infineon Technologies AG (Infineon) is supplying this software for use with
 * Infineon's microcontrollers.
 * This file can be freely distributed within development tools that are
 * supporting such microcontrollers.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 * OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 * INFINEON SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 */

/**
 * @file xmc4_gpio.h
 * @date 20 Feb, 2015
 * @version 1.0.2
 *
 * History <br>
 *
 * Version 1.0.0 Initial <br>
 */

#ifndef XMC4_GPIO_H
#define XMC4_GPIO_H

/*******************************************************************************
 * HEADER FILES
 *******************************************************************************/

#include "xmc_common.h"

#if UC_FAMILY == XMC4

#include "xmc4_gpio_map.h"

/**
 * @addtogroup XMClib XMC Peripheral Library
 * @{
 */

/**
 * @addtogroup GPIO
 * @{
 */

/*******************************************************************************
 * MACROS
 *******************************************************************************/

#if defined(PORT0)
#define XMC_GPIO_PORT0 ((XMC_GPIO_PORT_t *) PORT0_BASE)
#define XMC_GPIO_CHECK_PORT0(port) (port == XMC_GPIO_PORT0)
#else
#define XMC_GPIO_CHECK_PORT0(port) 0
#endif

#if defined(PORT1)
#define XMC_GPIO_PORT1 ((XMC_GPIO_PORT_t *) PORT1_BASE)
#define XMC_GPIO_CHECK_PORT1(port) (port == XMC_GPIO_PORT1)
#else
#define XMC_GPIO_CHECK_PORT1(port) 0
#endif

#if defined(PORT2)
#define XMC_GPIO_PORT2 ((XMC_GPIO_PORT_t *) PORT2_BASE)
#define XMC_GPIO_CHECK_PORT2(port) (port == XMC_GPIO_PORT2)
#else
#define XMC_GPIO_CHECK_PORT2(port) 0
#endif

#if defined(PORT3)
#define XMC_GPIO_PORT3 ((XMC_GPIO_PORT_t *) PORT3_BASE)
#define XMC_GPIO_CHECK_PORT3(port) (port == XMC_GPIO_PORT3)
#else
#define XMC_GPIO_CHECK_PORT3(port) 0
#endif

#if defined(PORT4)
#define XMC_GPIO_PORT4 ((XMC_GPIO_PORT_t *) PORT4_BASE)
#define XMC_GPIO_CHECK_PORT4(port) (port == XMC_GPIO_PORT4)
#else
#define XMC_GPIO_CHECK_PORT4(port) 0
#endif

#if defined(PORT5)
#define XMC_GPIO_PORT5 ((XMC_GPIO_PORT_t *) PORT5_BASE)
#define XMC_GPIO_CHECK_PORT5(port) (port == XMC_GPIO_PORT5)
#else
#define XMC_GPIO_CHECK_PORT5(port) 0
#endif

#if defined(PORT6)
#define XMC_GPIO_PORT6 ((XMC_GPIO_PORT_t *) PORT6_BASE)
#define XMC_GPIO_CHECK_PORT6(port) (port == XMC_GPIO_PORT6)
#else
#define XMC_GPIO_CHECK_PORT6(port) 0
#endif

#if defined(PORT14)
#define XMC_GPIO_PORT14 ((XMC_GPIO_PORT_t *) PORT14_BASE)
#define XMC_GPIO_CHECK_PORT14(port) (port == XMC_GPIO_PORT14)
#else
#define XMC_GPIO_CHECK_PORT14(port) 0
#endif

#if defined(PORT15)
#define XMC_GPIO_PORT15 ((XMC_GPIO_PORT_t *) PORT15_BASE)
#define XMC_GPIO_CHECK_PORT15(port) (port == XMC_GPIO_PORT15)
#else
#define XMC_GPIO_CHECK_PORT15(port) 0
#endif

#define XMC_GPIO_CHECK_PORT(port) (XMC_GPIO_CHECK_PORT0(port) || \
                                   XMC_GPIO_CHECK_PORT1(port) || \
                                   XMC_GPIO_CHECK_PORT2(port) || \
                                   XMC_GPIO_CHECK_PORT3(port) || \
                                   XMC_GPIO_CHECK_PORT4(port) || \
                                   XMC_GPIO_CHECK_PORT5(port) || \
                                   XMC_GPIO_CHECK_PORT6(port) || \
                                   XMC_GPIO_CHECK_PORT14(port) || \
                                   XMC_GPIO_CHECK_PORT15(port))

#define XMC_GPIO_CHECK_OUTPUT_PORT(port) (XMC_GPIO_CHECK_PORT0(port) || \
                                          XMC_GPIO_CHECK_PORT1(port) || \
                                          XMC_GPIO_CHECK_PORT2(port) || \
                                          XMC_GPIO_CHECK_PORT3(port) || \
                                          XMC_GPIO_CHECK_PORT4(port) || \
                                          XMC_GPIO_CHECK_PORT5(port) || \
                                          XMC_GPIO_CHECK_PORT6(port))

#define XMC_GPIO_CHECK_ANALOG_PORT(port) (XMC_GPIO_CHECK_PORT14(port) || \
                                          XMC_GPIO_CHECK_PORT15(port))

#define XMC_GPIO_CHECK_MODE(mode) ((mode == XMC_GPIO_MODE_INPUT_TRISTATE) ||\
                                   (mode == XMC_GPIO_MODE_INPUT_PULL_DOWN) ||\
                                   (mode == XMC_GPIO_MODE_INPUT_PULL_UP) ||\
                                   (mode == XMC_GPIO_MODE_INPUT_SAMPLING) ||\
                                   (mode == XMC_GPIO_MODE_INPUT_INVERTED_TRISTATE) ||\
                                   (mode == XMC_GPIO_MODE_INPUT_INVERTED_PULL_DOWN) ||\
                                   (mode == XMC_GPIO_MODE_INPUT_INVERTED_PULL_UP) ||\
                                   (mode == XMC_GPIO_MODE_INPUT_INVERTED_SAMPLING) ||\
                                   (mode == XMC_GPIO_MODE_OUTPUT_PUSH_PULL) ||\
                                   (mode == XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT1) ||\
                                   (mode == XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT2) ||\
                                   (mode == XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT3) ||\
                                   (mode == XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT4) ||\
                                   (mode == XMC_GPIO_MODE_OUTPUT_OPEN_DRAIN) ||\
                                   (mode == XMC_GPIO_MODE_OUTPUT_OPEN_DRAIN_ALT1) ||\
                                   (mode == XMC_GPIO_MODE_OUTPUT_OPEN_DRAIN_ALT2) ||\
                                   (mode == XMC_GPIO_MODE_OUTPUT_OPEN_DRAIN_ALT3) ||\
                                   (mode == XMC_GPIO_MODE_OUTPUT_OPEN_DRAIN_ALT4))

#define XMC_GPIO_CHECK_OUTPUT_STRENGTH(strength) ((strength == XMC_GPIO_OUTPUT_STRENGTH_STRONG_SHARP_EDGE) ||\
                                                 (strength == XMC_GPIO_OUTPUT_STRENGTH_STRONG_MEDIUM_EDGE) ||\
                                                 (strength == XMC_GPIO_OUTPUT_STRENGTH_STRONG_SOFT_EDGE) ||\
                                                 (strength == XMC_GPIO_OUTPUT_STRENGTH_STRONG_SLOW_EDGE) ||\
                                                 (strength == XMC_GPIO_OUTPUT_STRENGTH_MEDIUM) ||\
                                                 (strength == XMC_GPIO_OUTPUT_STRENGTH_WEAK))

/*******************************************************************************
 * ENUMS
 *******************************************************************************/

/**
 * Defines output strength and slew rate of a pin. Use type \a XMC_GPIO_OUTPUT_STRENGTH_t for this enum.
 *
 */
typedef enum XMC_GPIO_OUTPUT_STRENGTH
{
  XMC_GPIO_OUTPUT_STRENGTH_STRONG_SHARP_EDGE  = 0x0U,  /**<  Defines pad driver mode, for high speed 3.3V LVTTL outputs */
  XMC_GPIO_OUTPUT_STRENGTH_STRONG_MEDIUM_EDGE = 0x1U,  /**<  Defines pad driver mode, for high speed 3.3V LVTTL outputs  */
  XMC_GPIO_OUTPUT_STRENGTH_STRONG_SOFT_EDGE   = 0x2U,  /**<  Defines pad driver mode, medium speed 3.3V LVTTL outputs  */
  XMC_GPIO_OUTPUT_STRENGTH_STRONG_SLOW_EDGE   = 0x3U,  /**<  Defines pad driver mode, medium speed 3.3V LVTTL outputs  */
  XMC_GPIO_OUTPUT_STRENGTH_MEDIUM             = 0x4U,  /**<  Defines pad driver mode, for low speed 3.3V LVTTL outputs  */
  XMC_GPIO_OUTPUT_STRENGTH_WEAK               = 0x7U   /**<  Defines pad driver mode, low speed 3.3V LVTTL outputs  */
} XMC_GPIO_OUTPUT_STRENGTH_t;


/*******************************************************************************
 * DATA STRUCTURES
 *******************************************************************************/
/**
 *  Structure points  port hardware registers. Use type XMC_GPIO_PORT_t for this structure.
 */

typedef struct XMC_GPIO_PORT {
  __IO uint32_t  OUT;			/**< The port output register determines the value of a GPIO pin when it is selected by
  	  	  	  	  	  	  	  	  	  	  Pn_IOCRx as output */
  __O  uint32_t  OMR;			/**< The port output modification register contains control bits that make it possible
  	  	  	  	  	  	  	  	  	 to individually set, reset, or toggle the logic state of a single port line*/
  __I  uint32_t  RESERVED0[2];
  __IO uint32_t  IOCR[4];		/**< The port input/output control registers select the digital output and input driver
											functionality and characteristics of a GPIO port pin */
  __I  uint32_t  RESERVED1;
  __I  uint32_t  IN;			/**< The logic level of a GPIO pin can be read via the read-only port input register
  	  	  	  	  	  	  	  	  	  Pn_IN */
  __I  uint32_t  RESERVED2[6];
  __IO uint32_t  PDR[2];		/**< Pad Driver Mode Registers */

  __I  uint32_t  RESERVED3[6];
  __IO uint32_t  PDISC;			/**< Pin Function Decision Control Register is to disable/enable the digital pad
  	  	  	  	  	  	  	  	  	 structure in shared analog and digital ports*/
  __I  uint32_t  RESERVED4[3];
  __IO uint32_t  PPS;			/**< Pin Power Save Register */
  __IO uint32_t  HWSEL;			/**< Pin Hardware Select Register */
} XMC_GPIO_PORT_t;

/**
 *  Structure initializes port pin. Use type XMC_GPIO_CONFIG_t for this structure.
 */
typedef struct XMC_GPIO_CONFIG
{
  XMC_GPIO_MODE_t mode;							/**< Defines the direction and characteristics of a pin */
  XMC_GPIO_OUTPUT_LEVEL_t output_level;			/**< Defines output level of a pin */
  XMC_GPIO_OUTPUT_STRENGTH_t output_strength;	/**< Defines pad driver mode of a pin */
} XMC_GPIO_CONFIG_t;

/*******************************************************************************
 * API PROTOTYPES
 *******************************************************************************/


/**
 *
 * @param  port		constant pointer pointing to GPIO port, to access hardware register Pn_PDR.
 * @param  pin		Port pin number.
 * @param  strength Output driver mode selection. Refer data structure @ref XMC_GPIO_OUTPUT_STRENGTH_t for details.
 *
 * @return None
 *
 * \par<b>Description:</b><br>
 * Sets port pin output strength and slew rate. It configures hardware registers Pn_PDR. \a strength is initially
 * configured during initialization in XMC_GPIO_Init(). Call this API to alter output driver mode as needed later in
 * the program.
 *
 * \par<b>Related APIs:</b><BR>
 *  None
 *
 * \par<b>Note:</b><br>
 * Prior to this api, user has to configure port pin to output mode using XMC_GPIO_SetMode().
 *
 */

void XMC_GPIO_SetOutputStrength(XMC_GPIO_PORT_t *const port, const uint8_t pin, XMC_GPIO_OUTPUT_STRENGTH_t strength);

/**
 * @} (end addtogroup GPIO)
 */

/**
 * @} (end addtogroup XMClib)
 */

#endif /* UC_FAMILY == XMC4 */

#endif /* XMC4_GPIO_H */
 
