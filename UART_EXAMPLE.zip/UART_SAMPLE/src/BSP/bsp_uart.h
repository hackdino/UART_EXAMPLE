/*
 * bsp_uart.h
 *
 *  Created on: May 4, 2015
 *      Author: nfranz
 */

#ifndef SRC_BSP_BSP_UART_H_
#define SRC_BSP_BSP_UART_H_

#define UART_TX P0_1
#define UART_RX P0_0

#include <xmc_gpio.h>
#include <xmc_uart.h>
#include <stdio.h>

_Bool BSP_UART_Init(void) ;

#endif /* SRC_BSP_BSP_UART_H_ */
