/**
 * @file app.c
 *
 * @mainpage Example to use UART of Relax Kit
 * 			 Look COM-Task in app.c
 * 			 Look BSP_IntHandler_Uart_Recive in bsp_init.c
 * 			 Look BSP_UART_Init in bsp_uart.c
 *
 * 			 Was developed by Ney Fränz according to the following pattern:
 * 		  => https://doc.micrium.com/display/osiiidoc/Keeping+the+Data+in+Scope
 *
 * 		  Start Byte => 0x1  Stop Byte => 0x17
 * 		  PIN_Layout: RXD = P0.0  TXD = P0.1 Mode: 8N1 9600
 * 		  Example: 0x1 0x46 0x48 0x54 0x57 0x17
 * 		  		|Start|"F" | "H"| "T"| "W"|Stop|
 *
 * @author Ney Fränz, UAS Technikum Wien
 * @revision 0.1
 * @date 11-2015
 */

/******************************************************************* INCLUDES */
#include <app_cfg.h>
#include <cpu_core.h>
#include <os.h>

#include <bsp.h>
#include <bsp_sys.h>
#include <bsp_int.h>

#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

#include <xmc_uart.h>
#include <xmc_gpio.h>

#include <GPIO.h>

#include <lib_math.h>

#if SEMI_HOSTING
#include <debug_lib.h>
#endif

#if JLINK_RTT
#include <SEGGER_RTT.h>
#include <SEGGER_RTT_Conf.h>
#endif

/******************************************************************** DEFINES */

#define NACK 0x15
#define ACK  0x6

/********************************************************* FILE LOCAL GLOBALS */
static  CPU_STK  AppStartTaskStk[APP_CFG_TASK_START_STK_SIZE];
static  OS_TCB   AppStartTaskTCB;

static  CPU_STK  AppTaskComStk[APP_CFG_TASK_COM_STK_SIZE];
static  OS_TCB   AppTaskComTCB;

/*Memory Block*/
OS_MEM      Mem_Partition;

CPU_CHAR  	MyPartitionStorage[10][20]= { "\0" };

/*Message Queue*/
OS_Q        RPM_ISR;

/******************************************************* FILE LOCAL PROTOTPES */
static  void  AppTaskStart (void  *p_arg);
static  void  AppTaskCreate(void);
static  void  AppObjCreate (void);

static  void  AppTaskCom 			(void  *p_arg);

static 	void MemCreate (void);
static 	void MesQueueCreate (void);
/************************************************************ FUNCTIONS/TASKS */

/**
 * @function MesQueueCreate()
 * @brief Creates a Message Queue to communicate
 * 		  from Uart_Isr to Com_Task.
 * @param none
 * @returns none
 */
static void MesQueueCreate (void){

	OS_ERR      err;

	OSQCreate((OS_Q     *)&RPM_ISR,
			(CPU_CHAR *)"ISR Queue",
			(OS_MSG_QTY)10,
			(OS_ERR   *)&err);

	if(err != OS_ERR_NONE )
		APP_TRACE_DBG(("Error OSQCreate \n"));

}

/**
 * @function MemCreate()
 * @brief Creates Memory Block to save data from UART.
 * @params none
 * @returns none
 */
static void MemCreate (void){

	OS_ERR      err;

	OSMemCreate((OS_MEM    *)&Mem_Partition,
			(CPU_CHAR  *)"Mem Partition",
			(void      *)&MyPartitionStorage[0][0],
			(OS_MEM_QTY ) 10,
			(OS_MEM_SIZE)20 * sizeof(CPU_CHAR),
			(OS_ERR    *)&err);

	if(err != OS_ERR_NONE )
		APP_TRACE_DBG(("Error OSmemCreate\n"));
}



/*********************************************************************** MAIN */
/**
 * @function main
 * @params none
 * @returns 0 always
 *
 * @brief This is the standard entry point for C code.
 */
int main(void)
{
	OS_ERR  err;

	/* Disable all interrupts. */
	BSP_IntDisAll();
	/* Enable Interrupt UART*/
	BSP_IntEn(BSP_INT_ID_USIC1_01);//**
	BSP_IntEn(BSP_INT_ID_USIC1_00);//**

	/* Init uC/OS-III */
	OSInit(&err);

	/* Create the start task */
	OSTaskCreate((OS_TCB     *)&AppStartTaskTCB,
			(CPU_CHAR   *)"Startup Task",
			(OS_TASK_PTR )AppTaskStart,
			(void       *)0,
			(OS_PRIO     )APP_CFG_TASK_START_PRIO,
			(CPU_STK    *)&AppStartTaskStk[0],
			(CPU_STK_SIZE)APP_CFG_TASK_START_STK_SIZE / 10u,
			(CPU_STK_SIZE)APP_CFG_TASK_START_STK_SIZE,
			(OS_MSG_QTY  )0u,
			(OS_TICK     )0u,
			(void       *)0,
			(OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
			(OS_ERR     *)&err);

	/* Start multitasking (i.e., give control to uC/OS-III) */
	OSStart(&err);

	while (1) {
		;
	}
	return 0;
}

/*************************************************************** STARTUP TASK */

/**
 * @function AppTaskStart
 * @ params p_arg ... argument passed to AppTaskStart() by OSTaskCreate()
 * @returns none
 *
 * @brief Startup (init) task that loads board support functions, initializes
 *        CPU services, the memory, the systick timer, etc. and finally invokes
 *        other application tasks.
 */
static void AppTaskStart (void *p_arg)
{
	CPU_INT32U  cpu_clk_freq;
	CPU_INT32U  cnts;
	OS_ERR      err_os;


	(void)p_arg;

	/* initialize BSP functions */
	BSP_Init();
	/* initialize the uC/CPU services */
	CPU_Init();

	/* determine SysTick reference frequency */
	cpu_clk_freq = BSP_SysClkFreqGet();
	/* determine nbr SysTick increments */
	cnts         = cpu_clk_freq
			/ (CPU_INT32U)OSCfg_TickRate_Hz;
	/* init uCOS-III periodic time src (SysTick) */
	OS_CPU_SysTickInit(cnts);

	/* initialize memory management module */
	Mem_Init();
	/* initialize mathematical module */
	Math_Init();

	/* init DEBUG Support */
#if SEMI_HOSTING
	initRetargetSwo();
#endif

#if JLINK_RTT
	SEGGER_RTT_ConfigDownBuffer(0, NULL, NULL, 0, SEGGER_RTT_MODE_BLOCK_IF_FIFO_FULL);
	SEGGER_RTT_ConfigUpBuffer(0, NULL, NULL, 0, SEGGER_RTT_MODE_BLOCK_IF_FIFO_FULL);
#endif

	/* compute CPU capacity with no task running */
#if (OS_CFG_STAT_TASK_EN > 0u)
	OSStatTaskCPUUsageInit(&err_os);
#endif

	APP_TRACE_DBG(("\n\n\r"));
	APP_TRACE_INFO(("Creating Application Objects...\n\r"));
	/* create application objects */
	AppObjCreate();

	APP_TRACE_INFO(("Creating Application Tasks...\n\r"));
	/* create application tasks */
	AppTaskCreate();

	/*Create Memory*/
	MemCreate();
	/*Create Message Queue*/
	MesQueueCreate();

	while (DEF_TRUE) {
		/* Suspend current task*/
		OSTaskSuspend((OS_TCB *)0,
				&err_os);
	}
}

/**
 * @function AppTaskCreate()
 * @brief Creates two application tasks.
 * @params none
 * @returns none
 */
static void  AppTaskCreate (void)
{
	OS_ERR      err;

	/* create AppTask_COM */
	OSTaskCreate((OS_TCB     *)&AppTaskComTCB,
			(CPU_CHAR   *)"TaskCOM",
			(OS_TASK_PTR )AppTaskCom,
			(void       *)0,
			(OS_PRIO     )APP_CFG_TASK_COM_PRIO,
			(CPU_STK    *)&AppTaskComStk[0],
			(CPU_STK_SIZE)APP_CFG_TASK_COM_STK_SIZE / 10u,
			(CPU_STK_SIZE)APP_CFG_TASK_COM_STK_SIZE,
			(OS_MSG_QTY  )0u,
			(OS_TICK     )0u,
			(void       *)0,
			(OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
			(OS_ERR     *)&err);

}


/**
 * @function AppObjCreate()
 * @brief Creates two application objects.
 * @params none
 * @returns none
 */
static  void  AppObjCreate (void)
{

}

/**
 * @function AppTaskCom
 * @ params p_arg ... argument passed to AppTaskCom() by AppTaskCreate()
 * @returns none
 *
 * @brief Task for Communication between UART_ISR and Task1
 * 		  Was developed by Ney Fränz according to the following pattern:
 * 		  => https://doc.micrium.com/display/osiiidoc/Keeping+the+Data+in+Scope
 *
 * 		  Start Byte => 0x1  Stop Byte => 0x17
 * 		  PIN_Layout: RXD = P0.0  TXD = P0.1 Mode: 8N1 9600
 * 		  Example: 0x1 0x46 0x48 0x54 0x57 0x17
 * 		  		|Start|"F" | "H"| "T"| "W"|Stop|
 */
static void AppTaskCom (void *p_arg)
{
	void        	*p_msg;
	OS_ERR      	err_os;
	OS_MSG_SIZE  	msg_size;
	CPU_TS       	ts;
	CPU_CHAR	 	*pdata1;
	CPU_CHAR		msg[10] = { "\0" };

	(void)p_arg;

	while (DEF_TRUE) {

		/*Wait until a message receive*/
		p_msg = OSQPend(&RPM_ISR,
				0,
				OS_OPT_PEND_BLOCKING,
				&msg_size,
				&ts,
				&err_os);

		if (err_os != OS_ERR_NONE) {
			APP_TRACE_DBG(("Error OSQPend Com_Task\n"));
		}
		/*Check CRC Sum*/
			//TODO
			//Send NACK return if CRC not correct
			//OSMemPut Mem_Partition
			//continue wait for the next message

		/*Send ACK return*/
		XMC_UART_CH_Transmit(XMC_UART1_CH1, ACK);

		/*Copy Message to Char Buffer*/
		pdata1 = (CPU_CHAR*)p_msg;
		memcpy(msg,pdata1,msg_size);


		/*OSMemPut Mem_Partition*/
		OSMemPut(&Mem_Partition,
				(void *)pdata1,
				&err_os);

		/*Print Receive Message*/
		printf("Message: %s\n",msg);
		/*Print Length of Message*/
		printf("Length: %d\n",msg_size);
		/* Clear Buffer */
		memset(msg, 0, sizeof msg);

	}
}


/** EOF */
